package com.example.backend.service;

import com.example.backend.dto.ProductDto;
import com.example.backend.entities.*;
import com.example.backend.exceptions.ResourceNotFoundEx;
import com.example.backend.mapper.ProductMapper;
import com.example.backend.repositories.ProductRepository;
import com.example.backend.specification.ProductSpecification;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

  @Autowired
  private ProductRepository productRepository;

  @Autowired
  private CategoryService categoryService;

  @Autowired//1
  private ProductMapper productMapper;//1

  @Override
  public Product addProduct(ProductDto productDto) {
    Product product = productMapper.mapToProductEntity(productDto);//1
    return productRepository.save(product);
  }

  @Override
  public List<ProductDto> getAllProducts(UUID categoryId, UUID typeId) {
    Specification<Product> productSpecification= Specification.where(null);

    if(null != categoryId){
      productSpecification = productSpecification.and(ProductSpecification.hasCategoryId(categoryId));
    }
    if(null != typeId){
      productSpecification = productSpecification.and(ProductSpecification.hasCategoryTypeId(typeId));
    }
    List<Product> products = productRepository.findAll(productSpecification);
    return productMapper.getProductDtos(products);
  }

  @Override
  public ProductDto getProductBySlug(String slug) {
    Product product = productRepository.findBySlug(slug);
    if(null == product){
      throw new ResourceNotFoundEx("Product Not Found!");
    }
    ProductDto productDto = productMapper.mapProductToDto(product);
    productDto.setCategoryId(product.getCategory().getId());
    productDto.setCategoryTypeId(product.getCategoryType().getId());
    productDto.setVariants(productMapper.mapProductVariantListToDto(product.getProductVariants()));
    productDto.setProductResources(productMapper.mapProductResourcesListDto(product.getResources()));
    return productDto;
  }

  @Override
  public ProductDto getProductById(UUID id) {
    Product product = productRepository.findById(id).orElseThrow(()->new ResourceNotFoundEx("Product Not Found!"));
    ProductDto productDto = productMapper.mapProductToDto(product);
    productDto.setCategoryId(product.getCategory().getId());
    productDto.setCategoryTypeId(product.getCategoryType().getId());
    productDto.setVariants(productMapper.mapProductVariantListToDto(product.getProductVariants()));
    productDto.setProductResources(productMapper.mapProductResourcesListDto(product.getResources()));
    return productDto;
  }

  @Override
  public Product updateProduct(ProductDto productDto) {
    Product product= productRepository.findById(productDto.getId()).orElseThrow(()-> new ResourceNotFoundEx("Product Not Found!"));
    return productRepository.save(productMapper.mapToProductEntity(productDto));
  }
}