package org.example.goldmanshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldmanShopApplicationTests {

  @Test
  void contextLoads() {
  }

}
