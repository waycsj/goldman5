package org.example.goldmanshop.Dto;

import java.util.UUID;

public class ProductDto {
//
//  private UUID id;
//  private String name;
//
//  // 기본 생성자
//  public ProductDto() {}
//
//  // 생성자
//  public ProductDto(UUID id, String name) {
//    this.id = id;
//    this.name = name;
//  }
//
//  // Getter와 Setter
//  public UUID getId() {
//    return id;
//  }
//
//  public void setId(UUID id) {
//    this.id = id;
//  }
//
//  public String getName() {
//    return name;
//  }
//
//  public void setName(String name) {
//    this.name = name;
//  }
}
